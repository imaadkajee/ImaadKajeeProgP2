﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CulinaryCompanionimaad;
using System.Collections.Generic;

namespace CulinaryCompanionTest
{
    [TestClass]
    public class RecipeTests
    {
        [TestMethod]
        public void CalculateTotalCalories_ShouldReturnCorrectSum()
        {
            // Arrange
            var recipe = new Recipe
            {
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Flour", Quantity = 2, Unit = "cups", Calories = 200, FoodGroup = "Grains" },
                    new Ingredient { Name = "Eggs", Quantity = 2, Unit = "pieces", Calories = 150, FoodGroup = "Protein" }
                }
            };

            // Act
            double totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(350, totalCalories);
        }

        [TestMethod]
        public void OnHighCalories_ShouldTriggerForHighCalorieRecipe()
        {
            // Arrange
            bool eventTriggered = false;
            var recipe = new Recipe
            {
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Flour", Quantity = 2, Unit = "cups", Calories = 200, FoodGroup = "Grains" },
                    new Ingredient { Name = "Eggs", Quantity = 2, Unit = "pieces", Calories = 150, FoodGroup = "Protein" }
                }
            };

            RecipeManager.OnHighCalories += (recipeName, totalCalories) =>
            {
                eventTriggered = true;
                Assert.AreEqual("Test Recipe", recipeName);
                Assert.AreEqual(350, totalCalories);
            };

            // Act
            recipe.Name = "Test Recipe";
            double totalCalories = recipe.CalculateTotalCalories();
            if (totalCalories > 300)
            {
                RecipeManager.OnHighCalories?.Invoke(recipe.Name, totalCalories);
            }

            // Assert
            Assert.IsTrue(eventTriggered);

            // Unsubscribe from the event to avoid side effects in other tests
            RecipeManager.OnHighCalories -= (recipeName, totalCalories) =>
            {
                eventTriggered = true;
                Assert.AreEqual("Test Recipe", recipeName);
                Assert.AreEqual(350, totalCalories);
            };
        }
    }
}
