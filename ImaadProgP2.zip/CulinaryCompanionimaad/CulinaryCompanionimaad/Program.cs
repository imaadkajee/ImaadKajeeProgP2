﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CulinaryCompanionimaad
{
    internal class Program
    {
        public delegate void HighCalorieHandler(string recipeName, double totalCalories);
        public static event HighCalorieHandler OnHighCalories;

        static void Main(string[] args)
        {
            // Subscribe to the OnHighCalories event
            OnHighCalories += HandleHighCaloriesNotification;

            List<Recipe> recipes = new List<Recipe>();

            bool continueEntering = true;
            while (continueEntering)
            {
                Recipe recipe = GatherRecipeDetails();
                recipes.Add(recipe);

                // Ask if the user wants to enter another recipe
                Console.WriteLine("Do you want to enter another recipe? (Enter 'Yes' for Yes or any other key for No)");
                string choice = Console.ReadLine();
                continueEntering = choice.ToUpper() == "YES";
            }

            // Display the list of recipes alphabetically
            recipes = recipes.OrderBy(r => r.Name).ToList();
            Console.WriteLine("List of Recipes:");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            // User selects a recipe to display
            int selectedRecipeIndex = GetIntegerInput("Enter the number of the recipe you want to view:") - 1;
            if (selectedRecipeIndex >= 0 && selectedRecipeIndex < recipes.Count)
            {
                DisplayRecipe(recipes[selectedRecipeIndex]);

                // Handle scaling and resetting
                HandleRecipeScaling(recipes[selectedRecipeIndex]);
            }
        }

        static void HandleRecipeScaling(Recipe recipe)
        {
            Console.WriteLine("Do you want to scale the recipe? (Enter 'Yes' for Yes or any other key for No)");
            string scaleChoice = Console.ReadLine();
            if (scaleChoice.ToUpper() == "YES")
            {
                recipe.StoreOriginalQuantities(); // Store original quantities
                double scalingFactor = ReadDoubleInput("Enter the scaling factor (0.5 for half, 2 for double, 3 for triple):", false);
                ScaleRecipe(recipe, scalingFactor);

                // Display the scaled recipe details
                Console.WriteLine($"Scaled Recipe (by a factor of {scalingFactor}):");
                DisplayRecipe(recipe);

                // Ask if the user wants to reset the quantities back to their original values
                Console.WriteLine("Do you want to reset the quantities to their original values? (Enter 'Y' for Yes or any other key for No)");
                string resetChoice = Console.ReadLine();
                if (resetChoice.ToUpper() == "Y")
                {
                    recipe.ResetQuantities(); // Reset quantities
                    Console.WriteLine("Quantities reset to original values:");
                    DisplayRecipe(recipe);
                }
            }
        }

        static Recipe GatherRecipeDetails()
        {
            Recipe recipe = new Recipe();

            recipe.Name = GetInput("Enter the name of the recipe:");

            int numIngredients = GetIntegerInput("Enter the number of ingredients:");
            recipe.Ingredients = GatherIngredients(numIngredients);

            int numSteps = GetIntegerInput("Enter the number of steps:");
            recipe.Steps = GatherSteps(numSteps);

            // Calculate total calories and notify if exceeds 300
            double totalCalories = recipe.CalculateTotalCalories();
            if (totalCalories > 300)
            {
                OnHighCalories?.Invoke(recipe.Name, totalCalories);
            }

            return recipe;
        }

        static List<Ingredient> GatherIngredients(int numIngredients)
        {
            List<Ingredient> ingredients = new List<Ingredient>();
            for (int i = 0; i < numIngredients; i++)
            {
                Ingredient ingredient = new Ingredient();

                ingredient.Name = GetInput($"Enter the name of ingredient {i + 1}:");
                ingredient.Quantity = GetDoubleInput($"Enter the quantity of {ingredient.Name} (greater than 0):", x => x > 0);
                ingredient.Unit = GetInput($"Enter the unit of measurement for {ingredient.Name}:");
                ingredient.Calories = GetDoubleInput($"Enter the calories for {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}:", x => x >= 0);
                ingredient.FoodGroup = GetInput($"Enter the food group for {ingredient.Name}:");

                ingredients.Add(ingredient);
            }
            return ingredients;
        }

        static List<Step> GatherSteps(int numSteps)
        {
            List<Step> steps = new List<Step>();
            for (int i = 0; i < numSteps; i++)
            {
                Step step = new Step();
                step.Description = GetInput($"Enter description for step {i + 1}:");
                steps.Add(step);
            }
            return steps;
        }

        static void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine($"Recipe: {recipe.Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} - {ingredient.Calories} calories, Food Group: {ingredient.FoodGroup}");
            }
            Console.WriteLine($"Total Calories: {recipe.CalculateTotalCalories()}");
            Console.WriteLine("Steps:");
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                Console.WriteLine($"Step {i + 1}: {recipe.Steps[i].Description}");
            }
        }

        static string GetInput(string prompt)
        {
            Console.WriteLine(prompt);
            return Console.ReadLine();
        }

        static int GetIntegerInput(string prompt)
        {
            return GetInput(prompt).ParseIntOrDefault();
        }

        static double GetDoubleInput(string prompt, Func<double, bool> validation)
        {
            double value;
            do
            {
                value = GetInput(prompt).ParseDoubleOrDefault();
                if (!validation(value))
                {
                    Console.WriteLine("Please enter a valid value.");
                }
            } while (!validation(value));
            return value;
        }

        static double ReadDoubleInput(string prompt, bool allowZero = true)
        {
            double value;
            bool isValidInput = false;

            do
            {
                Console.WriteLine(prompt);
                string input = Console.ReadLine();

                if (double.TryParse(input, out value))
                {
                    if (allowZero || value > 0)
                    {
                        isValidInput = true;
                    }
                    else
                    {
                        Console.WriteLine("Please enter a value greater than 0.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }
            } while (!isValidInput);

            return value;
        }

        static void ScaleRecipe(Recipe recipe, double factor)
        {
            foreach (var ingredient in recipe.Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        static void HandleHighCaloriesNotification(string recipeName, double totalCalories)
        {
            Console.WriteLine($"Warning: The recipe '{recipeName}' exceeds 300 calories with a total of {totalCalories} calories.");
        }
    }

    public static class Extensions
    {
        public static int ParseIntOrDefault(this string value)
        {
            int result;
            int.TryParse(value, out result);
            return result;
        }

        public static double ParseDoubleOrDefault(this string value)
        {
            double result;
            double.TryParse(value, out result);
            return result;
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class Step
    {
        public string Description { get; set; }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }
        private List<double> originalQuantities; // Store original quantities

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
            originalQuantities = new List<double>();
        }

        // Store original quantities
        public void StoreOriginalQuantities()
        {
            originalQuantities.Clear();
            foreach (var ingredient in Ingredients)
            {
                originalQuantities.Add(ingredient.Quantity);
            }
        }

        // Reset quantities back to original values
        public void ResetQuantities()
        {
            for (int i = 0; i < Ingredients.Count; i++)
            {
                Ingredients[i].Quantity = originalQuantities[i];
            }
        }

        // Calculate total calories
        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories);
        }
    }
}
